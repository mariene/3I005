# -*- coding: utf-8 -*-
"""
Created on Wed Feb 24 16:22:24 2016

@author: 3300432
"""

from huffman_bis import *
from Entropie import *
import string
from TME2 import *
import math

def proba_textes(liste):
    d = {}
    for i in range (len(liste)):
        compte = count_ngrams(liste[i],1)
        liste_proba = DicoToDicoProba(compte)
        d[i]=liste_proba
        return d

#moyenne des proba obtenu avec plusieurs textes d'une meme langue             
def moyenne_texte(dico):
    d = {}
    for dico in dico.values():
        for char in dico:
            if d.has_key(char):
                d[char] += dico[char]
            else:
                d.update({char:dico[char]})
    for elem in d:
        d[elem] = d[elem]/3
    return d

#@param word est le mot à faire tester
#@param langue est la liste de probabilites de chaque lettre dans la langue à tester
#@return somme des log de proba de chaque lettre dans la langue
def proba_wl(word,langue):
    word = word.lower()
    somme_log = 0
    for char in word:
         if char in string.lowercase:          
                somme_log = somme_log + math.log(langue[char])
    return somme_log*(1./3)
    
    
francais = moyenne_texte(proba_textes(["bouleDeSuif.txt","arseneLupin.txt","montecristo.txt"]))
anglais = moyenne_texte(proba_textes(["warandpeace.txt","moby.txt","astro.txt"]))
allemand = moyenne_texte(proba_textes(["faust.txt","kleine.txt","Iphiginie.txt"]))

#Detecte la langue du mot passé en argument>>>>>>le resultat peut être faux<<<<<<<
def DetecLangue_mot(mot):
    mot = mot.lower()
    som_log_fr = proba_wl(mot,francais)
    som_log_an = proba_wl(mot,anglais)    
    som_log_al = proba_wl(mot,allemand)
    liste = [som_log_al,som_log_fr,som_log_an]
    if(max(liste)==som_log_fr):
        #print("le texte ou le mot est en francais")
        return 0
    if(max(liste)==som_log_an):
        #print("le texte ou le mot est en anglais")
        return 1
    if(max(liste)==som_log_al):
        #print("le texte ou le mot est en allemand")
        return 2
        
        
def DetecLangue_Texte(Filename):
       contenu=""
       with codecs.open(Filename,encoding="utf-8") as f:
           for char in f.read():#lecture fichier + copie dans contenu
               contenu += char.lower()
       contenu=unicodedata.normalize("NFKD",contenu).encode("ascii","ignore")
       #print(contenu)
       vote = {"francais":0 ,"anglais":0,"allemand":0}
       mot = ""
       for char in contenu:
           if char != " ":
               mot += char
           else:
               langue = DetecLangue_mot(mot)
               if(langue==0):
                   vote["francais"] += 1
               if(langue==1):
                   vote["anglais"] += 1
               if(langue==2):
                   vote["allemand"] += 1
               mot = ""
       print vote
       maximum = max(vote.values())
       for elem in vote:
           if vote[elem] == maximum:
               langue = elem
       print("la langue du texte est :" +langue)
       f.close() 

DetecLangue_Texte("astro.txt")